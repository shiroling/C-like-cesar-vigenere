#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

char *chiffrementCesar(char *text,int cle);

char *déchiffrementCesar(char *text,int cle);